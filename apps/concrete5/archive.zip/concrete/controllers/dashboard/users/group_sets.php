<?php 
defined('C5_EXECUTE') or die("Access Denied.");

class DashboardUsersGroupSetsController extends Concrete5_Controller_Dashboard_Users_Group_Sets {


}