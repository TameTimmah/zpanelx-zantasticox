<?php 
defined('C5_EXECUTE') or die("Access Denied.");
class DashboardPagesTypesAddController extends Concrete5_Controller_Dashboard_Pages_Types_Add {
	

}