<?php 
defined('C5_EXECUTE') or die("Access Denied.");
class DashboardPagesTypesController extends Concrete5_Controller_Dashboard_Pages_Types {
	


}