<?php 
	defined('C5_EXECUTE') or die("Access Denied.");	
	class ImageBlockController extends Concrete5_Controller_Block_Image {


	}