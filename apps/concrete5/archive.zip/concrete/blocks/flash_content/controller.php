<?php 
	defined('C5_EXECUTE') or die("Access Denied.");
	class FlashContentBlockController extends Concrete5_Controller_Block_FlashContent {


	}