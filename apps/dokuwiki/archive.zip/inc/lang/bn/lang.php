<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Foysol <ragebot1125@gmail.com>
 */
$lang['encoding']              = 'utf-8';
$lang['direction']             = 'itr';
$lang['doublequoteopening']    = '"';
$lang['doublequoteclosing']    = '"';
$lang['singlequoteopening']    = '\'';
$lang['singlequoteclosing']    = '\'';
$lang['apostrophe']            = '\'';
$lang['btn_edit']              = 'এই পৃষ্ঠা সম্পাদনা করুন';
$lang['btn_source']            = 'দেখান পাতা উৎস';
$lang['btn_show']              = 'দেখান পৃষ্ঠা';
$lang['btn_create']            = 'এই পৃষ্ঠা তৈরি করুন';
$lang['btn_search']            = 'অনুসন্ধান';
$lang['btn_save']              = 'Save';
$lang['btn_preview']           = 'পূর্বরূপ';
$lang['btn_top']               = 'উপরে ফিরে যান ';
$lang['btn_newer']             = '<< আরো সাম্প্রতিক';
$lang['btn_older']             = 'কম সাম্প্রতিক >>';
$lang['btn_revs']              = 'প্রাচীন সংশোধন';
$lang['btn_recent']            = 'সাধিত পরিবর্তনসমূহ';
$lang['btn_upload']            = 'আপলোড করুন';
